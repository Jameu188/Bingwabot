# Bingwa Telegram Bot (Render-ready)

This repo contains the Telegram bot + PayHero STK payment flow.

## Deploy to Render

1. Create a new **Web Service** on Render and connect your GitHub repo (or upload this folder).
2. Set:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
3. Add environment variables (Render Dashboard → Environment):

| Key | Required | Notes |
|---|---:|---|
| `TELEGRAM_TOKEN` | ✅ | BotFather token |
| `PAYHERO_USERNAME` | ✅ | PayHero API username |
| `PAYHERO_PASSWORD` | ✅ | PayHero API password |
| `ADMIN_ID` | ✅ | Your Telegram numeric ID (admin) |
| `BOT_USERNAME` | ⚠️ | Default: `bingwa1_bot` |
| `BASE_URL` | ✅ | Your public Render URL, e.g. `https://your-service.onrender.com` |
| `PRUNE_INACTIVE_DAYS` | ❌ | Default: `365` |

> The PayHero callback URL is automatically built as: `BASE_URL + /payhero/callback`

## Local run

```bash
npm install
export TELEGRAM_TOKEN=...
export PAYHERO_USERNAME=...
export PAYHERO_PASSWORD=...
export ADMIN_ID=...
export BASE_URL=http://localhost:10000
npm start
```

## Notes
- If you want a banner, add `banner.jpg` next to `index.js`.
- Admin must press `/start` at least once so Telegram allows bot → admin messages.
